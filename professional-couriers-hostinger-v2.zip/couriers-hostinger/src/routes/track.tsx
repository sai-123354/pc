import { createFileRoute } from "@tanstack/react-router";
import { PageLayout, PageHero } from "@/components/site/PageLayout";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { useCallback, useEffect, useRef, useState } from "react";
import { z } from "zod";
import { supabase } from "@/integrations/supabase/client";
import { STATUS_STEPS } from "@/lib/tracking";
import { Check, Circle, Package, Truck, MapPin, Loader2, ArrowRight } from "lucide-react";
import { format } from "date-fns";
import { Link } from "@tanstack/react-router";

const searchSchema = z.object({ t: z.string().optional() });

export const Route = createFileRoute("/track")({
  head: () => ({
    meta: [
      { title: "Track Shipment — The Professional Couriers — Piduguralla" },
      { name: "description", content: "Track your Professional Couriers shipment in real time using your PDR tracking number." },
      { property: "og:title", content: "Track your shipment — Piduguralla" },
      { property: "og:description", content: "Enter your PDR number to see live shipment status." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  validateSearch: (s) => searchSchema.parse(s),
  component: TrackPage,
});

function TrackPage() {
  const { t } = Route.useSearch();
  const [tn, setTn] = useState(t ?? "");
  const [loading, setLoading] = useState(false);
  const [row, setRow] = useState<any>(null);
  const [err, setErr] = useState<string | null>(null);

  const requestId = useRef(0);
  const lookup = useCallback(async (value: string) => {
    const currentRequest = ++requestId.current;
    setLoading(true); setErr(null); setRow(null);
    try {
      const { data, error } = await supabase.from("shipments").select("*").eq("tracking_number", value.trim().toUpperCase()).maybeSingle();
      if (currentRequest !== requestId.current) return;
      if (error) return setErr("Unable to check your shipment. Please try again.");
      if (!data) return setErr("No shipment found with that tracking number.");
      setRow(data);
    } catch {
      if (currentRequest === requestId.current) setErr("Unable to check your shipment. Please try again.");
    } finally {
      if (currentRequest === requestId.current) setLoading(false);
    }
  }, []);

  // Auto lookup if search param present
  useEffect(() => {
    setTn(t ?? "");
    if (t?.trim()) void lookup(t);
    else { requestId.current++; setRow(null); setErr(null); setLoading(false); }
    return () => { requestId.current++; };
  }, [t, lookup]);

  const stepIndex = row ? STATUS_STEPS.indexOf(row.status as any) : -1;

  return (
    <PageLayout>
      <PageHero eyebrow="Track" title="Where's my shipment?" subtitle="Enter your PDR tracking number to view live status and delivery timeline." />
      <section className="mx-auto max-w-4xl px-4 py-12">
        <form onSubmit={(e) => { e.preventDefault(); if (tn.trim()) lookup(tn.trim()); }} className="card-elevated flex gap-2 p-3">
          <Input aria-label="Tracking number" required value={tn} onChange={(e) => setTn(e.target.value)} placeholder="e.g. PDR48392" className="uppercase" />
          <Button type="submit" className="btn-hero" disabled={loading}>{loading ? <Loader2 className="h-4 w-4 animate-spin" /> : "Track"}</Button>
        </form>
        {err && <p className="mt-4 rounded-lg bg-destructive/10 p-3 text-sm text-destructive">{err}</p>}

        {row && (
          <div className="mt-8 space-y-6">
            <div className="card-elevated p-6">
              <div className="flex flex-wrap items-start justify-between gap-3">
                <div>
                  <p className="text-xs uppercase tracking-widest text-muted-foreground">Tracking</p>
                  <p className="text-2xl font-black text-primary">{row.tracking_number}</p>
                </div>
                <span className="rounded-full bg-primary px-4 py-1.5 text-sm font-bold text-primary-foreground">{row.status}</span>
              </div>
              <div className="mt-5 grid gap-4 sm:grid-cols-2 md:grid-cols-4">
                <InfoBlock label="Sender" value={row.sender_name} sub={row.sender_city} />
                <InfoBlock label="Receiver" value={row.receiver_name} sub={row.receiver_city} />
                <InfoBlock label="Origin → Destination" value={`${row.sender_city} → ${row.receiver_city}`} />
                <InfoBlock label="Booked" value={format(new Date(row.booking_date), "dd MMM yyyy")} sub={format(new Date(row.booking_date), "hh:mm a")} />
              </div>
              <div className="mt-4">
                <Link to="/receipt/$tracking" params={{ tracking: row.tracking_number }} className="inline-flex items-center gap-1 text-sm font-semibold text-primary hover:underline">
                  View receipt <ArrowRight className="h-4 w-4" />
                </Link>
              </div>
            </div>

            <div className="card-elevated p-6">
              <h3 className="mb-6 text-lg font-bold">Delivery Timeline</h3>
              <ol className="space-y-4">
                {STATUS_STEPS.map((step, i) => {
                  const done = i <= stepIndex;
                  const active = i === stepIndex;
                  return (
                    <li key={step} className="flex items-start gap-3">
                      <div className={`mt-0.5 grid h-8 w-8 shrink-0 place-items-center rounded-full ${done ? "bg-primary text-white" : "bg-muted text-muted-foreground"}`}>
                        {done ? <Check className="h-4 w-4" /> : <Circle className="h-3 w-3" />}
                      </div>
                      <div>
                        <p className={`font-semibold ${active ? "text-primary" : done ? "text-foreground" : "text-muted-foreground"}`}>{step}</p>
                        {active && <p className="text-xs text-muted-foreground">Current status</p>}
                      </div>
                    </li>
                  );
                })}
              </ol>
            </div>
          </div>
        )}

        {!row && !err && (
          <div className="mt-10 grid gap-4 sm:grid-cols-3">
            {[
              { icon: Package, t: "Enter number", d: "Use the PDR##### code from your receipt." },
              { icon: Truck, t: "See live status", d: "Timeline updates from booking to delivery." },
              { icon: MapPin, t: "Locate parcel", d: "Origin, destination and route info." },
            ].map((c) => (
              <div key={c.t} className="card-elevated p-5">
                <c.icon className="h-5 w-5 text-primary" />
                <p className="mt-3 font-semibold">{c.t}</p>
                <p className="mt-1 text-sm text-muted-foreground">{c.d}</p>
              </div>
            ))}
          </div>
        )}
      </section>
    </PageLayout>
  );
}

function InfoBlock({ label, value, sub }: { label: string; value: string; sub?: string }) {
  return (
    <div>
      <p className="text-[11px] font-semibold uppercase tracking-widest text-muted-foreground">{label}</p>
      <p className="mt-1 font-semibold text-foreground">{value}</p>
      {sub && <p className="text-xs text-muted-foreground">{sub}</p>}
    </div>
  );
}