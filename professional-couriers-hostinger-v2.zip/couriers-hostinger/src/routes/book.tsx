import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { PageLayout, PageHero } from "@/components/site/PageLayout";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { cloneElement, isValidElement, useId, useMemo, useState } from "react";
import { z } from "zod";
import { supabase } from "@/integrations/supabase/client";
import { generateUniqueTracking, calcVolumetric } from "@/lib/tracking";
import { toast } from "sonner";
import { Loader2 } from "lucide-react";

export const Route = createFileRoute("/book")({
  head: () => ({
    meta: [
      { title: "Book a Courier — The Professional Couriers — Piduguralla" },
      { name: "description", content: "Book your domestic courier online in under 2 minutes. Instant tracking number and printable receipt." },
      { property: "og:title", content: "Book a Courier — Piduguralla" },
      { property: "og:description", content: "Fast, easy online courier booking with instant receipt and PDR tracking." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: BookPage,
});

const schema = z.object({
  sender_name: z.string().min(2),
  sender_gst: z.string().optional(),
  sender_mobile: z.string().min(6),
  sender_email: z.string().email().optional().or(z.literal("")),
  sender_address: z.string().min(3),
  sender_city: z.string().min(2),
  sender_state: z.string().min(2),
  sender_pincode: z.string().min(4),
  receiver_name: z.string().min(2),
  receiver_mobile: z.string().min(6),
  receiver_email: z.string().email().optional().or(z.literal("")),
  receiver_address: z.string().min(3),
  receiver_city: z.string().min(2),
  receiver_state: z.string().min(2),
  receiver_pincode: z.string().min(4),
  contents: z.string().min(2),
  pieces: z.coerce.number().int().positive(),
  declared_value: z.coerce.number().nonnegative(),
  actual_weight: z.coerce.number().positive(),
  length: z.coerce.number().nonnegative(),
  width: z.coerce.number().nonnegative(),
  height: z.coerce.number().nonnegative(),
  shipment_type: z.string(),
  transport_mode: z.string(),
  courier_charges: z.coerce.number().nonnegative(),
  gst_amount: z.coerce.number().nonnegative(),
  other_charges: z.coerce.number().nonnegative(),
  payment_mode: z.string(),
});

type Form = z.input<typeof schema>;

const initial: Form = {
  sender_name: "", sender_gst: "", sender_mobile: "", sender_email: "", sender_address: "", sender_city: "", sender_state: "", sender_pincode: "",
  receiver_name: "", receiver_mobile: "", receiver_email: "", receiver_address: "", receiver_city: "", receiver_state: "", receiver_pincode: "",
  contents: "", pieces: 1 as any, declared_value: 0 as any, actual_weight: 0.5 as any,
  length: 0 as any, width: 0 as any, height: 0 as any,
  shipment_type: "Parcel", transport_mode: "Surface",
  courier_charges: 100 as any, gst_amount: 18 as any, other_charges: 0 as any, payment_mode: "Cash",
};

function BookPage() {
  const navigate = useNavigate();
  const [f, setF] = useState<Form>(initial);
  const [submitting, setSubmitting] = useState(false);

  const set = (k: keyof Form) => (e: any) => setF((p) => ({ ...p, [k]: e?.target ? e.target.value : e }));

  const volumetric = useMemo(() => calcVolumetric(+f.length, +f.width, +f.height), [f.length, f.width, f.height]);
  const total = useMemo(() => Number(f.courier_charges || 0) + Number(f.gst_amount || 0) + Number(f.other_charges || 0), [f.courier_charges, f.gst_amount, f.other_charges]);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    const parsed = schema.safeParse(f);
    if (!parsed.success) {
      toast.error(parsed.error.issues[0]?.message ?? "Please fill required fields");
      return;
    }
    setSubmitting(true);
    try {
      const tracking = await generateUniqueTracking();
      const insertData = {
        ...parsed.data,
        sender_gst: parsed.data.sender_gst || null,
        sender_email: parsed.data.sender_email || null,
        receiver_email: parsed.data.receiver_email || null,
        tracking_number: tracking,
        airway_bill: tracking,
        volumetric_weight: volumetric,
        total_amount: total,
        status: "Booked",
        branch_name: "Head Office",
      };
      const { error } = await supabase.from("shipments").insert(insertData);
      if (error) throw error;
      toast.success(`Booking confirmed — ${tracking}`);
      navigate({ to: "/receipt/$tracking", params: { tracking } });
    } catch (e: any) {
      toast.error(e.message ?? "Booking failed");
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <PageLayout>
      <PageHero eyebrow="Book" title="Create a new booking" subtitle="Fill in the sender, receiver and parcel details. We'll generate your PDR tracking number and receipt automatically." />
      <form onSubmit={submit} className="mx-auto max-w-6xl space-y-8 px-4 py-12">
        <Section title="Sender Information">
          <Grid>
            <Field label="Name *"><Input value={f.sender_name} onChange={set("sender_name")} required /></Field>
            <Field label="GST Number"><Input value={f.sender_gst} onChange={set("sender_gst")} /></Field>
            <Field label="Mobile *"><Input value={f.sender_mobile} onChange={set("sender_mobile")} required /></Field>
            <Field label="Email"><Input type="email" value={f.sender_email} onChange={set("sender_email")} /></Field>
            <Field label="Address *" className="md:col-span-2"><Textarea rows={2} value={f.sender_address} onChange={set("sender_address")} required /></Field>
            <Field label="City *"><Input value={f.sender_city} onChange={set("sender_city")} required /></Field>
            <Field label="State *"><Input value={f.sender_state} onChange={set("sender_state")} required /></Field>
            <Field label="Pincode *"><Input value={f.sender_pincode} onChange={set("sender_pincode")} required /></Field>
          </Grid>
        </Section>

        <Section title="Receiver Information">
          <Grid>
            <Field label="Name *"><Input value={f.receiver_name} onChange={set("receiver_name")} required /></Field>
            <Field label="Mobile *"><Input value={f.receiver_mobile} onChange={set("receiver_mobile")} required /></Field>
            <Field label="Email"><Input type="email" value={f.receiver_email} onChange={set("receiver_email")} /></Field>
            <Field label="Address *" className="md:col-span-2"><Textarea rows={2} value={f.receiver_address} onChange={set("receiver_address")} required /></Field>
            <Field label="City *"><Input value={f.receiver_city} onChange={set("receiver_city")} required /></Field>
            <Field label="State *"><Input value={f.receiver_state} onChange={set("receiver_state")} required /></Field>
            <Field label="Pincode *"><Input value={f.receiver_pincode} onChange={set("receiver_pincode")} required /></Field>
          </Grid>
        </Section>

        <Section title="Parcel Details">
          <Grid>
            <Field label="Contents *"><Input value={f.contents} onChange={set("contents")} required /></Field>
            <Field label="Pieces *"><Input type="number" min={1} value={f.pieces} onChange={set("pieces")} required /></Field>
             <Field label="Declared Value (₹)"><Input type="number" step="0.01" min={0} value={f.declared_value} onChange={set("declared_value")} /></Field>
            <Field label="Actual Weight (kg) *"><Input type="number" step="0.01" min={0} value={f.actual_weight} onChange={set("actual_weight")} required /></Field>
             <Field label="Length (cm)"><Input type="number" step="0.01" min={0} value={f.length} onChange={set("length")} /></Field>
             <Field label="Width (cm)"><Input type="number" step="0.01" min={0} value={f.width} onChange={set("width")} /></Field>
             <Field label="Height (cm)"><Input type="number" step="0.01" min={0} value={f.height} onChange={set("height")} /></Field>
            <Field label="Volumetric Weight (kg)"><Input value={volumetric} readOnly className="bg-muted" /></Field>
            <Field label="Shipment Type *">
              <Select value={f.shipment_type} onValueChange={(v) => setF((p) => ({ ...p, shipment_type: v }))}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  {["Documents","Parcel","Fragile Item","Electronics","Medicine","Others"].map((v) => <SelectItem key={v} value={v}>{v}</SelectItem>)}
                </SelectContent>
              </Select>
            </Field>
            <Field label="Transport Mode *">
              <Select value={f.transport_mode} onValueChange={(v) => setF((p) => ({ ...p, transport_mode: v }))}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  {["Air","Surface"].map((v) => <SelectItem key={v} value={v}>{v}</SelectItem>)}
                </SelectContent>
              </Select>
            </Field>
          </Grid>
        </Section>

        <Section title="Charges & Payment">
          <Grid>
             <Field label="Courier Charges (₹)"><Input type="number" step="0.01" min={0} value={f.courier_charges} onChange={set("courier_charges")} /></Field>
             <Field label="GST (₹)"><Input type="number" step="0.01" min={0} value={f.gst_amount} onChange={set("gst_amount")} /></Field>
             <Field label="Other Charges (₹)"><Input type="number" step="0.01" min={0} value={f.other_charges} onChange={set("other_charges")} /></Field>
            <Field label="Total (₹)"><Input value={total.toFixed(2)} readOnly className="bg-muted font-bold" /></Field>
            <Field label="Payment Mode *">
              <Select value={f.payment_mode} onValueChange={(v) => setF((p) => ({ ...p, payment_mode: v }))}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  {["Cash","Credit","UPI"].map((v) => <SelectItem key={v} value={v}>{v}</SelectItem>)}
                </SelectContent>
              </Select>
            </Field>
          </Grid>
        </Section>

        <div className="sticky bottom-4 z-30 flex flex-wrap items-center justify-between gap-3 rounded-2xl border border-primary/20 bg-white/95 p-4 backdrop-blur shadow-[var(--shadow-brand)]">
          <div>
            <p className="text-xs uppercase tracking-widest text-muted-foreground">Total</p>
            <p className="text-2xl font-black text-primary">₹{total.toFixed(2)}</p>
          </div>
          <Button type="submit" size="lg" className="btn-hero" disabled={submitting}>
            {submitting ? <><Loader2 className="mr-2 h-4 w-4 animate-spin" /> Generating…</> : "Generate Receipt"}
          </Button>
        </div>
      </form>
    </PageLayout>
  );
}

function Section({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <div className="card-elevated p-6">
      <h2 className="mb-4 border-b border-border pb-3 text-lg font-bold text-primary">{title}</h2>
      {children}
    </div>
  );
}
function Grid({ children }: { children: React.ReactNode }) {
  return <div className="grid gap-4 md:grid-cols-3">{children}</div>;
}
function Field({ label, children, className }: { label: string; children: React.ReactNode; className?: string }) {
  const id = useId();
  return (
    <div className={className}>
      <Label id={`${id}-label`} htmlFor={id} className="mb-1.5 block text-xs font-semibold uppercase tracking-wider text-muted-foreground">{label}</Label>
      {isValidElement<{ id?: string; "aria-labelledby"?: string }>(children)
        ? cloneElement(children, { id, "aria-labelledby": `${id}-label` })
        : children}
    </div>
  );
}