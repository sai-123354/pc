import { createFileRoute } from "@tanstack/react-router";
import { PageLayout, PageHero } from "@/components/site/PageLayout";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";

export const Route = createFileRoute("/faq")({
  head: () => ({
    meta: [
      { title: "FAQ — The Professional Couriers — Piduguralla" },
      { name: "description", content: "Answers to common questions about booking, tracking, delivery time and pricing at Professional Couriers." },
      { property: "og:title", content: "Frequently Asked Questions — Piduguralla" },
      { property: "og:description", content: "Everything you need to know about Professional Couriers." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: FaqPage,
});

const FAQ = [
  { q: "How do I track my shipment?", a: "Enter your PDR tracking number on the Track page. Every booking gets a unique PDR##### number automatically." },
  { q: "What's the delivery time?", a: "Air: 1–2 business days between metros. Surface: 3–6 business days depending on distance." },
  { q: "How is volumetric weight calculated?", a: "Length × Width × Height ÷ 5000. We charge on whichever is higher — actual weight or volumetric weight." },
  { q: "What items can I not ship?", a: "Hazardous materials, perishables, cash, illegal or restricted items. See our services page for details." },
  { q: "Do you handle fragile items?", a: "Yes — mark the shipment type as Fragile at booking and our team applies extra care and packaging." },
  { q: "What payment modes are accepted?", a: "Cash on booking, UPI, and credit invoicing for corporate customers." },
];

function FaqPage() {
  return (
    <PageLayout>
      <PageHero eyebrow="Help" title="Frequently asked questions" />
      <section className="mx-auto max-w-3xl px-4 py-16">
        <Accordion type="single" collapsible className="w-full">
          {FAQ.map((f, i) => (
            <AccordionItem key={i} value={`f${i}`}>
              <AccordionTrigger className="text-left">{f.q}</AccordionTrigger>
              <AccordionContent className="text-muted-foreground">{f.a}</AccordionContent>
            </AccordionItem>
          ))}
        </Accordion>
      </section>
    </PageLayout>
  );
}