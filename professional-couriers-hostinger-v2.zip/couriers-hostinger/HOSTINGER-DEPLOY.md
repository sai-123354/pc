# Deploying to Hostinger (any plan, Git deployment)

The site is built as static files by GitHub, then Hostinger copies them.

1. Add the images listed in `MISSING-IMAGES.txt` into `public/__l5e/...` (they are not in the zip).
2. Push this project to your GitHub repo `main` branch (replace old files).
3. GitHub > repo > Actions > "Build for Hostinger" runs automatically. Wait for the green tick.
   (If it fails, open the run and send the error.) It creates a branch named `hostinger`.
4. Hostinger hPanel > Git for tpcpdr.com: set the branch to **hostinger**, install path `public_html`, then Deploy.
5. Open tpcpdr.com.
