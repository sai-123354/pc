# Deploy on Hostinger (Node.js Web App or VPS)

Node.js 20 or newer required.

## Hostinger Node.js Web App (GitHub import)
- Framework: Other / custom
- Install command: npm install
- Build command: npm run build:hostinger
- Start command: npm run start   (entry file: .output/server/index.mjs)
- Node version: 20 or 22
- Environment variables: copy every line from .env.example

## VPS
    npm install
    cp .env.example .env
    npm run build:hostinger
    PORT=3000 pm2 start .output/server/index.mjs --name couriers

Never commit a real .env file to GitHub.
