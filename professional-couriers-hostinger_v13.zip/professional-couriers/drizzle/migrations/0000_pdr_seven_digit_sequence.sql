CREATE SEQUENCE IF NOT EXISTS public.pdr_tracking_seq START WITH 1000001 MINVALUE 1000001 MAXVALUE 9999999;
CREATE OR REPLACE FUNCTION public.next_tracking_number()
RETURNS text LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE c text;
BEGIN
  LOOP
    c := 'PDR' || nextval('public.pdr_tracking_seq')::text;
    EXIT WHEN NOT EXISTS (SELECT 1 FROM public.shipments WHERE tracking_number = c);
  END LOOP;
  RETURN c;
END $$;
REVOKE ALL ON FUNCTION public.next_tracking_number() FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.next_tracking_number() TO anon, authenticated, service_role;