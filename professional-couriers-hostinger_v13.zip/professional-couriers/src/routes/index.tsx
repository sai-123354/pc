import { createFileRoute } from "@tanstack/react-router";
import { SiteHeader } from "@/components/site/SiteHeader";
import { ReferenceHome } from "@/components/site/ReferenceHome";
export const Route = createFileRoute("/")({
 head: () => ({meta:[
 {title:"The Professional Couriers — Piduguralla"},
 {name:"description",content:"The Professional Couriers — Piduguralla. Courier, cargo, COD, mailing, fulfillment and packing services."},
 {property:"og:title",content:"The Professional Couriers — Piduguralla"},
 {property:"og:description",content:"The ultimate service provider for your courier needs."},
 {property:"og:type",content:"website"},
 {name:"twitter:card",content:"summary_large_image"}
 ]}),
 component: HomePage,
});
function HomePage(){return <><SiteHeader /><ReferenceHome /></>;}
