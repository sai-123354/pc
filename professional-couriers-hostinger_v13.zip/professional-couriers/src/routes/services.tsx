import { createFileRoute } from "@tanstack/react-router";
import { PageLayout, PageHero } from "@/components/site/PageLayout";
import { Plane, Truck, FileText, Package, Pill, Cpu } from "lucide-react";

export const Route = createFileRoute("/services")({
  head: () => ({
    meta: [
      { title: "Domestic Courier Services — The Professional Couriers — Piduguralla" },
      { name: "description", content: "Air, surface, documents, parcels, fragile, medicine and electronics — reliable domestic courier services across India." },
      { property: "og:title", content: "Our Services — The Professional Couriers — Piduguralla" },
      { property: "og:description", content: "Comprehensive domestic courier services for every shipment type." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: ServicesPage,
});

function ServicesPage() {
  const services = [
    { icon: Plane, title: "Air Cargo", desc: "Same-day and next-day delivery for time-critical shipments across metros." },
    { icon: Truck, title: "Surface Cargo", desc: "Cost-effective ground delivery for bulk and non-urgent parcels." },
    { icon: FileText, title: "Documents", desc: "Secure document delivery with signature confirmation." },
    { icon: Package, title: "Parcels", desc: "Standard parcel service for personal and business shipments." },
    { icon: Cpu, title: "Electronics", desc: "Specialized handling and insured delivery for electronic goods." },
    { icon: Pill, title: "Medicine", desc: "Priority delivery for essential medicines and healthcare items." },
  ];
  return (
    <PageLayout>
      <PageHero eyebrow="Services" title="Every shipment. Every corner of India." subtitle="Choose from air or surface transport, with specialized handling for documents, fragile items, electronics and medicine." />
      <section className="mx-auto max-w-7xl px-4 py-16">
        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
          {services.map((s) => (
            <div key={s.title} className="card-elevated p-6 transition-transform hover:-translate-y-1">
              <div className="grid h-12 w-12 place-items-center rounded-xl bg-accent text-primary">
                <s.icon className="h-6 w-6" />
              </div>
              <h3 className="mt-4 text-lg font-bold">{s.title}</h3>
              <p className="mt-2 text-sm text-muted-foreground">{s.desc}</p>
            </div>
          ))}
        </div>
      </section>
    </PageLayout>
  );
}