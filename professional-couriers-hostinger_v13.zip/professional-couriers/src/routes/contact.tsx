import { createFileRoute } from "@tanstack/react-router";
import { PageLayout, PageHero } from "@/components/site/PageLayout";
import { Mail, Phone, MapPin } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { toast } from "sonner";

export const Route = createFileRoute("/contact")({
  head: () => ({
    meta: [
      { title: "Contact Us — The Professional Couriers — Piduguralla" },
      { name: "description", content: "Get in touch with Professional Couriers. Call, email or visit us for domestic courier support." },
      { property: "og:title", content: "Contact Professional Couriers — Piduguralla" },
      { property: "og:description", content: "We're here to help — 7 days a week." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: ContactPage,
});

function ContactPage() {
  return (
    <PageLayout>
      <PageHero eyebrow="Contact" title="Talk to us" subtitle="We reply to every enquiry within 24 hours." />
      <section className="mx-auto grid max-w-7xl gap-10 px-4 py-16 lg:grid-cols-2">
        <div className="space-y-6">
          <div className="flex items-start gap-3"><Phone className="mt-1 h-5 w-5 text-primary" /><div><p className="font-semibold">Phone</p><a className="block text-muted-foreground" href="tel:+919490056001">+91 9490056001</a><a className="block text-muted-foreground" href="tel:+917989166001">+91 7989166001</a></div></div>
          <div className="flex items-start gap-3"><Mail className="mt-1 h-5 w-5 text-primary" /><div className="min-w-0"><p className="font-semibold">Email</p><a className="break-all text-muted-foreground" href="mailto:venkata.medam@gmail.com">venkata.medam@gmail.com</a></div></div>
          <div><p className="font-semibold">Working Hours</p><p className="text-muted-foreground">Monday – Saturday: 9:00 AM – 9:00 PM</p><p className="text-muted-foreground">Sunday: Holiday</p></div>
          <div><p className="font-semibold">GSTIN</p><p className="text-muted-foreground">37CGEPM1248J1Z9</p></div>
          <div className="flex items-start gap-3"><MapPin className="mt-1 h-5 w-5 text-primary" /><div><p className="font-semibold">Piduguralla Office</p><p className="text-muted-foreground">The Professional Couriers, 12-210, Janapadu Road, N T R Circle, Piduguralla — 522413</p></div></div>
        </div>
        <form
          onSubmit={(e) => {
            e.preventDefault();
            const data = new FormData(e.currentTarget);
            const body = `Name: ${data.get("name")}\nEmail: ${data.get("email")}\n\n${data.get("message")}`;
            window.location.href = `mailto:venkata.medam@gmail.com?subject=${encodeURIComponent(String(data.get("subject") ?? ""))}&body=${encodeURIComponent(body)}`;
            toast.info("Your email app will open. Send your message there to contact the office.");
          }}
          className="card-elevated space-y-4 p-6"
        >
          <div className="grid gap-4 sm:grid-cols-2">
            <Input required name="name" aria-label="Full name" placeholder="Full name" />
            <Input required name="email" aria-label="Email" type="email" placeholder="Email" />
          </div>
          <Input required name="subject" aria-label="Subject" placeholder="Subject" />
          <Textarea required name="message" aria-label="Your message" placeholder="Your message" rows={5} />
          <Button type="submit" className="btn-hero w-full">Send Message</Button>
        </form>
      </section>
    </PageLayout>
  );
}