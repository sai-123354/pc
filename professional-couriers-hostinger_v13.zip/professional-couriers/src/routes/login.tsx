import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { Eye, EyeOff } from "lucide-react";
import { SiteHeader } from "@/components/site/SiteHeader";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";

export const Route = createFileRoute("/login")({
  head: () => ({ meta: [
    { title: "Customer & Branch Login — Professional Couriers Piduguralla" },
    { name: "description", content: "Customer and branch account access for The Professional Couriers, Piduguralla." },
    { property: "og:title", content: "Customer & Branch Login — Piduguralla" },
    { property: "og:description", content: "Choose customer or branch account access at Professional Couriers Piduguralla." },
    { property: "og:type", content: "website" },
    { name: "twitter:card", content: "summary_large_image" },
  ] }),
  component: LoginPage,
});

function LoginPage() {
  const [mode, setMode] = useState("customer");
  const [visible, setVisible] = useState(false);
  const [notice, setNotice] = useState("");
  return <div className="login-page"><SiteHeader /><main className="login-main">
    <section className="login-panel" aria-labelledby="portal-title">
      <Tabs value={mode} onValueChange={(value) => { setMode(value); setNotice(""); }}>
        <TabsList className="login-tabs" aria-label="Account type">
          <TabsTrigger value="customer" className="login-tab">Customer Login</TabsTrigger>
          <TabsTrigger value="branch" className="login-tab">Branch Login</TabsTrigger>
        </TabsList>
      </Tabs>
      <div className="login-content">
        <h1 id="portal-title">{mode === "customer" ? "Customer Portal" : "Branch Portal"}</h1>
        <p className="login-subtitle">{mode === "customer" ? "Track shipments and manage your account." : "Manage branch bookings and shipments."}</p>
        <form onSubmit={(event) => { event.preventDefault(); setNotice("Account access is not available yet. Please contact the office at 9490056001 or 7989166001."); }}>
          <div className="login-field"><Label htmlFor="login-email">Email ID</Label><Input id="login-email" type="email" placeholder="Enter your email" autoComplete="username" required /></div>
          <div className="login-field"><Label htmlFor="login-password">Password</Label><div className="login-password"><Input id="login-password" type={visible ? "text" : "password"} placeholder="Enter password" autoComplete="current-password" required /><Button variant="ghost" size="icon" type="button" aria-label={visible ? "Hide password" : "Show password"} title={visible ? "Hide password" : "Show password"} onClick={() => setVisible(!visible)}>{visible ? <EyeOff size={18} /> : <Eye size={18} />}</Button></div></div>
          <div className="login-forgot"><Button variant="link" type="button" onClick={() => setNotice("For account or password assistance, contact venkata.medam@gmail.com or call 9490056001.")}>Forgot password?</Button></div>
          <Button type="submit" className="login-submit">Login</Button>
          {notice && <p role="status" className="login-notice">{notice}</p>}
        </form>
      </div>
    </section>
  </main></div>;
}