import { createFileRoute } from "@tanstack/react-router";
import { PageLayout, PageHero } from "@/components/site/PageLayout";
import { MapPin, Phone } from "lucide-react";

export const Route = createFileRoute("/branches")({
  head: () => ({
    meta: [
      { title: "Branch Network — The Professional Couriers — Piduguralla" },
      { name: "description", content: "2,500+ branches across India. Find your nearest Professional Couriers office." },
      { property: "og:title", content: "Branch Network — Piduguralla" },
      { property: "og:description", content: "Find your nearest Professional Couriers branch across India." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: BranchesPage,
});

const BRANCHES = [
  { city: "Chennai", addr: "T. Nagar, Chennai — 600017", phone: "044 2814 5678" },
  { city: "Mumbai", addr: "Andheri East, Mumbai — 400069", phone: "022 2821 4567" },
  { city: "Delhi", addr: "Karol Bagh, New Delhi — 110005", phone: "011 2354 8899" },
  { city: "Bengaluru", addr: "Koramangala, Bengaluru — 560095", phone: "080 4123 7788" },
  { city: "Hyderabad", addr: "Ameerpet, Hyderabad — 500016", phone: "040 2374 5566" },
  { city: "Kolkata", addr: "Park Street, Kolkata — 700016", phone: "033 2287 4433" },
  { city: "Pune", addr: "Shivaji Nagar, Pune — 411005", phone: "020 2553 6677" },
  { city: "Ahmedabad", addr: "Navrangpura, Ahmedabad — 380009", phone: "079 2645 3322" },
  { city: "Jaipur", addr: "MI Road, Jaipur — 302001", phone: "0141 236 7788" },
];

function BranchesPage() {
  return (
    <PageLayout>
      <PageHero eyebrow="Nationwide" title="2,500+ branches across India" subtitle="From metros to tier-3 towns, our on-ground network is always nearby." />
      <section className="mx-auto max-w-7xl px-4 py-16">
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
          {BRANCHES.map((b) => (
            <div key={b.city} className="card-elevated p-5">
              <div className="flex items-center gap-2">
                <MapPin className="h-4 w-4 text-primary" />
                <h3 className="font-bold">{b.city}</h3>
              </div>
              <p className="mt-2 text-sm text-muted-foreground">{b.addr}</p>
              <p className="mt-2 flex items-center gap-2 text-sm"><Phone className="h-3.5 w-3.5 text-primary" /> {b.phone}</p>
            </div>
          ))}
        </div>
      </section>
    </PageLayout>
  );
}