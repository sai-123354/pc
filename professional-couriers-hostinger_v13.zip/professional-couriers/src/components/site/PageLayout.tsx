import type { ReactNode } from "react";
import { SiteHeader } from "./SiteHeader";
import { SiteFooter } from "./SiteFooter";

export function PageLayout({ children }: { children: ReactNode }) {
  return (
    <div className="min-h-screen bg-background">
      <SiteHeader />
      <main>{children}</main>
      <SiteFooter />
    </div>
  );
}

export function PageHero({ eyebrow, title, subtitle }: { eyebrow?: string; title: string; subtitle?: string }) {
  return (
    <section className="border-b border-border" style={{ backgroundImage: "var(--gradient-hero)" }}>
      <div className="mx-auto max-w-7xl px-4 pb-16 pt-32 text-primary-foreground sm:pb-20 sm:pt-36">
        {eyebrow && <p className="mb-3 text-xs font-semibold uppercase tracking-[0.3em] text-white/70">{eyebrow}</p>}
        <h1 className="max-w-3xl text-3xl font-black tracking-tight sm:text-5xl">{title}</h1>
        {subtitle && <p className="mt-4 max-w-2xl text-base text-white/80 sm:text-lg">{subtitle}</p>}
      </div>
    </section>
  );
}