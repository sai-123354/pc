import logo from "@/assets/reference/tpc-logo-new.png.asset.json";
export function Logo({ light: _light = false }: { light?: boolean }) {
  return <span className="reference-logo tpc-logo-new"><img src={logo.url} alt="The Professional Couriers — Piduguralla" /></span>;
}
