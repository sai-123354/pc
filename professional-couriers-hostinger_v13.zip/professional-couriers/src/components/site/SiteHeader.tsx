import { Link } from "@tanstack/react-router";
import { Menu, Phone, X } from "lucide-react";
import { useState } from "react";
import { Logo } from "./Logo";
import { Button } from "@/components/ui/button";
const nav = [{to:"/",label:"Home"},{to:"/services",label:"Services"},{to:"/track",label:"Track Parcel"},{to:"/about",label:"About Us"},{to:"/contact",label:"Contact"}] as const;
export function SiteHeader(){
 const [open,setOpen]=useState(false);
 return <header className="reference-header no-print"><div className="reference-pill"><Link to="/" aria-label="The Professional Couriers — Piduguralla"><Logo /></Link><nav className="reference-nav">{nav.map(n=><Link key={n.to} to={n.to} activeOptions={{exact:true}}>{n.label}</Link>)}</nav><div className="reference-actions"><a href="tel:+919490056001" className="reference-phone"><Phone size={14}/>+91 9490056001</a><Button asChild className="reference-login"><Link to="/login">Login →</Link></Button></div><Button variant="ghost" size="icon" className="reference-mobile-menu" aria-label={open ? "Close menu" : "Open menu"} aria-expanded={open} onClick={()=>setOpen(!open)}>{open?<X/>:<Menu/>}</Button></div>{open&&<nav className="reference-mobile-panel">{nav.map(n=><Link key={n.to} to={n.to} onClick={()=>setOpen(false)}>{n.label}</Link>)}<Button asChild className="reference-login"><Link to="/login" onClick={()=>setOpen(false)}>Login →</Link></Button></nav>}</header>;
}
