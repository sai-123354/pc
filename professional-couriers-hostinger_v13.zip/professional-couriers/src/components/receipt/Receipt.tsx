import { useEffect, useRef } from "react";
import QRCode from "qrcode";
import JsBarcode from "jsbarcode";
import { Logo } from "@/components/site/Logo";
import { format } from "date-fns";

export type ShipmentRow = {
  tracking_number: string;
  airway_bill: string;
  sender_name: string;
  sender_gst: string | null;
  sender_mobile: string;
  sender_email?: string | null;
  sender_address: string;
  sender_city: string;
  sender_state: string;
  sender_pincode: string;
  receiver_name: string;
  receiver_mobile: string;
  receiver_email?: string | null;
  receiver_address: string;
  receiver_city: string;
  receiver_state: string;
  receiver_pincode: string;
  contents: string;
  pieces: number;
  declared_value: number;
  actual_weight: number;
  length: number;
  width: number;
  height: number;
  volumetric_weight: number;
  shipment_type: string;
  transport_mode: string;
  courier_charges: number;
  gst_amount: number;
  other_charges: number;
  total_amount: number;
  payment_mode: string;
  branch_name: string;
  booking_date: string;
};

const COPIES = ["Sender's Copy", "Account's Copy", "POD Copy"] as const;

export function Receipt({ s }: { s: ShipmentRow }) {
  const areaRef = useRef<HTMLDivElement>(null);
  useEffect(() => {
    const fitPage = () => {
      const area = areaRef.current;
      if (!area) return;
      area.style.zoom = "1";
      area.style.zoom = String(Math.min(1, 1040 / area.getBoundingClientRect().height));
    };
    const reset = () => { if (areaRef.current) areaRef.current.style.zoom = ""; };
    window.addEventListener("beforeprint", fitPage);
    window.addEventListener("afterprint", reset);
    return () => { window.removeEventListener("beforeprint", fitPage); window.removeEventListener("afterprint", reset); };
  }, []);
  return (
    <div ref={areaRef} className="print-area receipt-sheet mx-auto max-w-[820px] text-black">
      {COPIES.map((c) => (
        <ConsignmentNote key={c} s={s} copy={c} />
      ))}
    </div>
  );
}

function ConsignmentNote({ s, copy }: { s: ShipmentRow; copy: string }) {
  const barRef = useRef<SVGSVGElement>(null);
  const qrRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    if (barRef.current) {
      try {
        JsBarcode(barRef.current, s.tracking_number, {
          format: "CODE128", height: 46, displayValue: false, margin: 0, width: 2,
        });
      } catch {}
    }
    if (qrRef.current) {
      QRCode.toCanvas(
        qrRef.current,
        JSON.stringify({
          tracking: s.tracking_number,
          sender: s.sender_name,
          receiver: s.receiver_name,
          date: s.booking_date,
        }),
        { width: 74, margin: 0 },
      ).catch(() => {});
    }
  }, [s]);

  const date = new Date(s.booking_date);
  const isPod = copy === "POD Copy";

  return (
    <div className="print-copy border-2 border-black bg-white text-[11px] leading-snug">
      {/* Header */}
      <div className="grid grid-cols-[1.55fr_1fr]">
        <div className="flex items-center gap-3 border-r-2 border-black p-2">
          <Logo />
          <div className="text-[10px]">
            <div className="font-bold">Professional Couriers Pvt. Ltd.</div>
            <div>Regd. Office: 12-210, Janapadu Road, N T R Circle, Piduguralla - 522413</div>
            <div>GSTIN: 37CGEPM1248J1Z9</div>
          </div>
        </div>
        <div className="grid grid-cols-2">
          <div className="grid grid-rows-2 border-r-2 border-black">
            <Cell>Origin: <b>{s.sender_city.toUpperCase()}</b></Cell>
            <Cell border={false}>Product: <b>{s.transport_mode.toUpperCase()}</b></Cell>
          </div>
          <div className="grid grid-rows-3">
            <Cell>Dest: <b>{s.receiver_city.toUpperCase()}</b></Cell>
            <Cell>Type: <b>{s.shipment_type.toUpperCase()}</b></Cell>
            <Cell border={false}>Date: <b>{format(date, "EEE MMM dd yyyy")}</b></Cell>
          </div>
        </div>
      </div>

      {/* Parties */}
      <div className="grid grid-cols-[1.55fr_1fr] border-t-2 border-black">
        <div className="border-r-2 border-black p-2">
          <div>Consignor's Name: <b>{s.sender_name.toUpperCase()}</b></div>
          <div>Consignor's Address: <b>{`${s.sender_address}, ${s.sender_city}, ${s.sender_state}, ${s.sender_pincode}`.toUpperCase()}</b></div>
          <div>GSTIN No.: <b>{s.sender_gst ?? ""}</b></div>
          <div>Phone: <b>{s.sender_mobile}</b> &nbsp; Email: <b>{s.sender_email ?? ""}</b></div>
        </div>
        <div className="p-2">
          <div>Customer Ref No: <b>{s.airway_bill}</b></div>
          <div>Consignee's Name: <b>{s.receiver_name.toUpperCase()}</b></div>
          <div>Consignee's Address: <b>{`${s.receiver_address}, ${s.receiver_city}, ${s.receiver_state}, ${s.receiver_pincode}`.toUpperCase()}</b></div>
          <div>GSTIN No.:</div>
          <div>Phone: <b>{s.receiver_mobile}</b> &nbsp; Email: <b>{s.receiver_email ?? ""}</b></div>
        </div>
      </div>

      {/* Body */}
      <div className="grid grid-cols-[0.85fr_0.7fr_1fr] border-t-2 border-black">
        {/* declaration column */}
        <div className="border-r-2 border-black p-2">
          <div className="font-semibold">Content Specification: <span className="font-bold">{s.contents}</span></div>
          <div className="mt-1 font-semibold">Paperwork Enclosed:</div>
          <p className="mt-2 text-center text-[10px]">
            I/We declare that this consignment does not contain personal mail, cash, jewellery,
            contraband, illegal drugs, any prohibited items and commodities which can cause safety
            hazards while transporting
          </p>
          <div className="mt-2 text-center font-bold underline">Sender's Signature &amp; Seal</div>
          <div className="mt-6 border-b border-black/70" />
          <p className="mt-1 text-center text-[9px]">
            I have read and understood terms &amp; conditions of carriage mentioned on
            www.professionalcouriers.in, and I agree to the same.
          </p>
        </div>

        {/* metrics column */}
        <div className="border-r-2 border-black">
          <Cell>Declared Value: <b>₹{s.declared_value}</b></Cell>
          <Cell>No Of Pieces: <b>{s.pieces}</b></Cell>
          <Cell>Actual Weight: <b>{s.actual_weight} Kg</b></Cell>
          <Cell>Ewaybill Number:</Cell>
          <Cell>Dim: <b>{s.length}×{s.width}×{s.height} cm</b></Cell>
          <Cell>Charged Weight: <b>{Math.max(s.actual_weight, s.volumetric_weight)} Kg</b></Cell>
          <div className="p-2 text-[10px]">
            <div>Name: <b>{s.branch_name}</b></div>
            <div>Address: <b>12-210, JANAPADU ROAD, N T R CIRCLE, PIDUGURALLA - 522413</b></div>
            <div>Phone: <b>9490056001 / 7989166001</b></div>
          </div>
        </div>

        {/* codes + risk column */}
        <div>
          <div className="flex items-center justify-center gap-3 border-b-2 border-black p-2">
            <svg ref={barRef} className="h-[46px]" />
            <canvas ref={qrRef} className="shrink-0" />
          </div>
          <div className="border-b-2 border-black py-1 text-center text-[13px]">
            AWB No: <b>{s.tracking_number}</b>
          </div>
          {isPod ? (
            <div className="grid grid-cols-2">
              <div className="border-r-2 border-black">
                <Cell>Receiver's Name:</Cell>
                <div className="p-2 pt-6">Phone Number:</div>
              </div>
              <div className="grid place-items-center p-2 text-center text-[12px]">
                Receiver's Signature and Stamp
              </div>
            </div>
          ) : (
            <div className="grid grid-cols-[1fr_0.8fr]">
              <div className="grid place-items-center border-r-2 border-black p-2 text-[14px] font-bold">
                Risk Surcharge
              </div>
              <div>
                <div className="flex items-center justify-between gap-2 border-b-2 border-black p-2">
                  <span>Owner</span><span className="h-4 w-4 rounded border border-black" />
                </div>
                <div className="flex items-center justify-between gap-2 p-2">
                  <span>Carrier</span><span className="h-4 w-4 rounded border border-black" />
                </div>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Footer */}
      <div className="grid grid-cols-[1.55fr_1fr] border-t-2 border-black text-[10px]">
        <div className="flex flex-wrap items-center justify-center gap-x-3 gap-y-1 border-r-2 border-black p-1">
          <span>venkata.medam@gmail.com</span>
          <span className="text-black/40">|</span>
          <span>9490056001 / 7989166001</span>
        </div>
        <div className="p-1">
          Amount collected (in Rs.): <b>₹{s.total_amount.toFixed(2)} ({s.payment_mode})</b>
        </div>
      </div>
      <div className="flex items-center justify-between border-t-2 border-black px-2 py-1 text-[10px] font-bold">
        <span className="flex-1 text-center">
          THIS DOCUMENT IS NOT A TAX INVOICE. WEIGHT CAPTURED BY PROFESSIONAL COURIERS WILL BE USED FOR INVOICE GENERATION.
        </span>
        <span className="w-32 text-right font-semibold">{copy}</span>
      </div>
    </div>
  );
}

function Cell({ children, border = true }: { children?: React.ReactNode; border?: boolean }) {
  return <div className={`px-2 py-1 ${border ? "border-b-2 border-black" : ""}`}>{children}</div>;
}