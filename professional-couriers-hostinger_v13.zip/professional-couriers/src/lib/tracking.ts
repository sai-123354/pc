import { supabase } from "@/integrations/supabase/client";

/** Tracking numbers are PDR + 7 digits, issued in order from PDR1000001 by the database. */
export const TRACKING_PATTERN = /^PDR\d{7}$/;

export async function generateUniqueTracking(): Promise<string> {
  const { data, error } = await supabase.rpc("next_tracking_number");
  if (error) throw error;
  if (typeof data !== "string" || !TRACKING_PATTERN.test(data)) {
    throw new Error("Could not generate unique tracking number");
  }
  return data;
}

export function calcVolumetric(l: number, w: number, h: number) {
  const v = (l * w * h) / 5000;
  return Number.isFinite(v) ? Math.round(v * 100) / 100 : 0;
}

export const STATUS_STEPS = [
  "Booked",
  "Picked Up",
  "Dispatched",
  "Hub Received",
  "In Transit",
  "Out For Delivery",
  "Delivered",
] as const;
export type ShipmentStatus = (typeof STATUS_STEPS)[number];