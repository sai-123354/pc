<!-- LOVABLE:BEGIN -->
> [!IMPORTANT]
> This project is connected to [Lovable](https://lovable.dev). Avoid rewriting
> published git history — force pushing, or rebasing/amending/squashing commits
> that are already pushed — as it rewrites history on Lovable's side and the
> user will likely lose their project history.
>
> Commits you push to the connected branch sync back to Lovable and show up in
> the editor, so keep the branch in a working state.
<!-- LOVABLE:END -->

- Keep public page chrome in shared site components and isolate reference homepage markup in ReferenceHome so booking and tracking remain unchanged.
- Deliver source archives without credentials, Git metadata, dependencies, or generated output so downloads are portable and safe.
- Route every Book Pickup action to the existing /book page, not Contact, so customers reach the courier booking form.
- Keep all login entry points linked to the shared /login page; customer and branch choices are presentation only until account permissions are implemented.
- Keep receipt print sizing isolated to receipt styles and scale oversized notes to the A4 printable height, so all three copies remain together without changing shipment data.
- Until message delivery is connected, hand contact enquiries to the visitor's email app and never claim they were sent, so customers receive an honest delivery status.
- Hostinger builds use the build:hostinger script (NITRO_PRESET=node-server) so the Lovable Cloudflare default stays untouched.
